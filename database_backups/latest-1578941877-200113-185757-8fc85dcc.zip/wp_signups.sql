CREATE TABLE IF NOT EXISTS `wp_signups` (
  `signup_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `activation_key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `meta` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`signup_id`),
  KEY `activation_key` (`activation_key`),
  KEY `user_email` (`user_email`),
  KEY `user_login_email` (`user_login`,`user_email`),
  KEY `domain_path` (`domain`(140),`path`(51))
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_signups`;
 
INSERT INTO `wp_signups` VALUES ('1', '', '', '', 'omhclient', 'Jessica.Labombard@onslow.org', '2019-11-08 17:51:33', '2019-11-08 17:51:33', '1', '95744326809683d4', 'a:2:{s:11:"add_to_blog";i:2;s:8:"new_role";s:6:"editor";}'); 
INSERT INTO `wp_signups` VALUES ('2', '', '', '', 'bluegravity', 'tom@bluegravity.com', '2019-12-16 20:27:27', '2019-12-16 20:32:29', '1', '2753c499db7943c5', 'a:2:{s:11:"add_to_blog";i:1;s:8:"new_role";s:13:"administrator";}');
# --------------------------------------------------------

