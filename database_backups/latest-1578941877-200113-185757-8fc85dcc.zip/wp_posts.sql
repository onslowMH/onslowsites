CREATE TABLE IF NOT EXISTS `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_posts`;
 
INSERT INTO `wp_posts` VALUES ('9', '1', '2017-01-30 22:00:44', '2017-01-30 22:00:44', '[email_verification]', 'Email Verification', '', 'publish', 'open', 'open', '', 'email-verification', '', '', '2017-01-30 22:00:44', '2017-01-30 22:00:44', '', '0', 'http://onslowsites.com/2017/01/30/email-verification/', '0', 'fmemailverification', '', '0'); 
INSERT INTO `wp_posts` VALUES ('10', '2', '2017-03-20 20:00:06', '2017-03-20 20:00:06', '<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Subject\n    [text your-subject] </label>\n\n<label> Your Message\n    [textarea your-message] </label>\n\n[submit "Send"]\nOnslow Sites "[your-subject]"\n[your-name] <wordpress@onslowsites.com>\nFrom: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Onslow Sites (https://onslowsites.com)\nsupport@redhammerworks.com\nReply-To: [your-email]\n\n0\n0\n\nOnslow Sites "[your-subject]"\nOnslow Sites <wordpress@onslowsites.com>\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Onslow Sites (https://onslowsites.com)\n[your-email]\nReply-To: support@redhammerworks.com\n\n0\n0\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.', 'Contact form 1', '', 'publish', 'open', 'open', '', 'contact-form-1', '', '', '2017-03-20 20:00:06', '2017-03-20 20:00:06', '', '0', 'http://onslowsites.com/?post_type=wpcf7_contact_form&p=10', '0', 'wpcf7_contact_form', '', '0'); 
INSERT INTO `wp_posts` VALUES ('11', '2', '2017-03-27 16:41:47', '2017-03-27 16:41:47', 'support@redhammerworks.com\ndarwinhadley', 'support@redhammerworks.com', '', 'publish', 'closed', 'closed', '', 'support-redhammerworks-com', '', '', '2017-03-27 16:41:47', '2017-03-27 16:41:47', '', '0', 'http://onslowsites.com/2017/03/27/support-redhammerworks-com/', '0', 'flamingo_contact', '', '0'); 
INSERT INTO `wp_posts` VALUES ('12', '2', '2017-03-27 16:41:47', '2017-03-27 16:41:47', 'maddy@heysaturday.com\nmaddyaman', 'maddy@heysaturday.com', '', 'publish', 'closed', 'closed', '', 'maddy-heysaturday-com', '', '', '2017-03-27 16:41:47', '2017-03-27 16:41:47', '', '0', 'http://onslowsites.com/2017/03/27/maddy-heysaturday-com/', '0', 'flamingo_contact', '', '0'); 
INSERT INTO `wp_posts` VALUES ('13', '2', '2017-03-27 16:41:47', '2017-03-27 16:41:47', 'tpope@heysaturday.com\nthecklapope', 'tpope@heysaturday.com', '', 'publish', 'closed', 'closed', '', 'tpope-heysaturday-com', '', '', '2017-03-27 16:41:47', '2017-03-27 16:41:47', '', '0', 'http://onslowsites.com/2017/03/27/tpope-heysaturday-com/', '0', 'flamingo_contact', '', '0'); 
INSERT INTO `wp_posts` VALUES ('15', '2', '2019-04-30 19:44:35', '2019-04-30 19:44:35', 'nick@heysaturday.com\nsaturdaydev', 'nick@heysaturday.com', '', 'publish', 'closed', 'closed', '', 'nick-heysaturday-com', '', '', '2019-04-30 19:44:35', '2019-04-30 19:44:35', '', '0', 'http://onslowsites.com/?post_type=flamingo_contact&#038;p=15', '0', 'flamingo_contact', '', '0'); 
INSERT INTO `wp_posts` VALUES ('18', '4', '2019-12-16 20:53:34', '2019-12-16 20:53:34', 'tom@bluegravity.com\nbluegravity', 'tom@bluegravity.com', '', 'publish', 'closed', 'closed', '', 'tom-bluegravity-com', '', '', '2019-12-16 20:53:34', '2019-12-16 20:53:34', '', '0', 'https://onslowsites.com/?post_type=flamingo_contact&#038;p=18', '0', 'flamingo_contact', '', '0'); 
INSERT INTO `wp_posts` VALUES ('23', '4', '2020-01-13 18:47:14', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2020-01-13 18:47:14', '0000-00-00 00:00:00', '', '0', 'https://onslowsites.com/?p=23', '0', 'post', '', '0');
# --------------------------------------------------------

