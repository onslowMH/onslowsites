CREATE TABLE IF NOT EXISTS `wp_registration_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `IP` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `date_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `IP` (`IP`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_registration_log`;
 
INSERT INTO `wp_registration_log` VALUES ('1', 'support@redhammerworks.com', '71.28.88.205', '2', '2012-11-07 15:28:41'); 
INSERT INTO `wp_registration_log` VALUES ('2', 'support@redhammerworks.com', '71.75.226.124', '3', '2013-11-01 12:02:20'); 
INSERT INTO `wp_registration_log` VALUES ('3', 'maddy@heysaturday.com', '75.190.136.123', '4', '2014-01-27 20:15:59'); 
INSERT INTO `wp_registration_log` VALUES ('4', 'support@redhammerworks.com', '24.74.158.207', '5', '2015-10-06 17:49:53');
# --------------------------------------------------------

