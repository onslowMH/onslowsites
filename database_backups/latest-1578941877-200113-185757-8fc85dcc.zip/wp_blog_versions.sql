CREATE TABLE IF NOT EXISTS `wp_blog_versions` (
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `db_version` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`blog_id`),
  KEY `db_version` (`db_version`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_blog_versions`;
 
INSERT INTO `wp_blog_versions` VALUES ('1', '44719', '2012-12-13 16:53:16'); 
INSERT INTO `wp_blog_versions` VALUES ('2', '44719', '2012-12-13 16:53:26'); 
INSERT INTO `wp_blog_versions` VALUES ('3', '38590', '2014-01-27 14:05:11'); 
INSERT INTO `wp_blog_versions` VALUES ('4', '44719', '2014-04-15 11:41:41'); 
INSERT INTO `wp_blog_versions` VALUES ('5', '44719', '2017-03-20 15:19:59');
# --------------------------------------------------------

