CREATE TABLE IF NOT EXISTS `wp_domain_mapping_logins` (
  `id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `blog_id` bigint(20) NOT NULL,
  `t` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
TRUNCATE TABLE `wp_domain_mapping_logins`;
 
INSERT INTO `wp_domain_mapping_logins` VALUES ('d1645efc7b85d48c5bb298e19bfd8864', '2', '2', '2017-10-09 13:45:34'); 
INSERT INTO `wp_domain_mapping_logins` VALUES ('5e57aedf2f9fa86b06bc69651f484298', '0', '2', '2018-02-28 05:35:52'); 
INSERT INTO `wp_domain_mapping_logins` VALUES ('28de00a193531d12c94e380030065cd0', '3', '5', '2018-05-24 14:24:27'); 
INSERT INTO `wp_domain_mapping_logins` VALUES ('e568833e91500a25c77bdace09780cac', '2', '5', '2018-06-14 16:07:08'); 
INSERT INTO `wp_domain_mapping_logins` VALUES ('e85a2d6b0f6cb7dbfd58cb1492bd2b1e', '3', '4', '2018-08-21 15:04:18');
# --------------------------------------------------------

