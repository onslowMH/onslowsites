CREATE TABLE IF NOT EXISTS `wp_blogs` (
  `blog_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `domain` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `public` tinyint(2) NOT NULL DEFAULT '1',
  `archived` tinyint(2) NOT NULL DEFAULT '0',
  `mature` tinyint(2) NOT NULL DEFAULT '0',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  `lang_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`blog_id`),
  KEY `domain` (`domain`(50),`path`(5)),
  KEY `lang_id` (`lang_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_blogs`;
 
INSERT INTO `wp_blogs` VALUES ('1', '1', 'onslowsites.com', '/', '2012-11-07 14:56:15', '0000-00-00 00:00:00', '1', '0', '0', '0', '0', '0'); 
INSERT INTO `wp_blogs` VALUES ('2', '1', 'onslowradiationoncology.onslowsites.com', '/', '2012-11-07 15:28:41', '2020-01-09 20:34:07', '1', '0', '0', '0', '0', '0'); 
INSERT INTO `wp_blogs` VALUES ('3', '1', 'onslowurology.onslowsites.com', '/', '2013-11-01 12:02:20', '2018-11-06 16:13:42', '1', '0', '0', '0', '1', '0'); 
INSERT INTO `wp_blogs` VALUES ('4', '1', 'onslowpulmonology.onslowsites.com', '/', '2014-01-27 20:15:59', '2019-12-30 13:14:43', '1', '0', '0', '0', '0', '0'); 
INSERT INTO `wp_blogs` VALUES ('5', '1', 'onslowsurgical.onslowsites.com', '/', '2015-10-06 17:49:53', '2019-05-06 14:04:35', '1', '0', '0', '0', '0', '0');
# --------------------------------------------------------

