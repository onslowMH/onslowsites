CREATE TABLE IF NOT EXISTS `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_users`;
 
INSERT INTO `wp_users` VALUES ('1', 'darwinhadley', '$P$BJqYQLsPULi6NEwvHP9bifjCibyNpU0', 'darwinhadley', 'support@redhammerworks.com', '', '2012-11-07 14:27:18', '', '0', 'darwinhadley', '0', '0'); 
INSERT INTO `wp_users` VALUES ('2', 'thecklapope', '$P$BxxLSEVmOT3eywC0kolBf.FzlKIEeT.', 'thecklapope', 'tpope@heysaturday.com', '', '2012-11-07 16:14:22', '79CfcEw2cvJ63LFmwJ1k', '0', 'thecklapope', '0', '0'); 
INSERT INTO `wp_users` VALUES ('3', 'maddyaman', '$P$BG5bxE2E98a6O3o.Ko6NuhJ4y1obXm.', 'maddyaman', 'maddy@heysaturday.com', '', '2013-11-01 12:17:15', '', '0', 'maddyaman', '0', '0'); 
INSERT INTO `wp_users` VALUES ('4', 'saturdaydev', '$P$BykOjjsG5OdzPsisvdRoE3SUJbgU6W1', 'saturdaydev', 'nick@heysaturday.com', '', '2019-04-30 19:44:02', '1556653442:$P$BOTnhD83GneucsNoNGdSeen.XzObEC.', '0', 'saturdaydev', '0', '0'); 
INSERT INTO `wp_users` VALUES ('5', 'omhclient', '$P$B84/idMxMmhJbBhTkQWTW8Ay4GGJzR/', 'omhclient', 'Jessica.Labombard@onslow.org', '', '2019-11-08 17:51:33', '', '0', 'omhclient', '0', '0'); 
INSERT INTO `wp_users` VALUES ('6', 'bluegravity', '$P$BFRYTxklFFzdd34lRPy.eZF4JbETve/', 'bluegravity', 'tom@bluegravity.com', '', '2019-12-16 20:32:29', '', '0', 'bluegravity', '0', '0');
# --------------------------------------------------------

