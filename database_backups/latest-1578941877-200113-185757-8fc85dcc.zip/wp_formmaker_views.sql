CREATE TABLE IF NOT EXISTS `wp_formmaker_views` (
  `form_id` int(11) NOT NULL,
  `views` int(50) NOT NULL,
  PRIMARY KEY (`form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
TRUNCATE TABLE `wp_formmaker_views`;

# --------------------------------------------------------

