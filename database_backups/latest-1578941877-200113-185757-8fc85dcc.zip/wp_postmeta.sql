CREATE TABLE IF NOT EXISTS `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
TRUNCATE TABLE `wp_postmeta`;
 
INSERT INTO `wp_postmeta` VALUES ('7', '10', '_form', '<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Subject\n    [text your-subject] </label>\n\n<label> Your Message\n    [textarea your-message] </label>\n\n[submit "Send"]'); 
INSERT INTO `wp_postmeta` VALUES ('8', '10', '_mail', 'a:8:{s:7:"subject";s:29:"Onslow Sites "[your-subject]"";s:6:"sender";s:39:"[your-name] <wordpress@onslowsites.com>";s:4:"body";s:174:"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Onslow Sites (https://onslowsites.com)";s:9:"recipient";s:26:"support@redhammerworks.com";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'); 
INSERT INTO `wp_postmeta` VALUES ('9', '10', '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:29:"Onslow Sites "[your-subject]"";s:6:"sender";s:40:"Onslow Sites <wordpress@onslowsites.com>";s:4:"body";s:116:"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Onslow Sites (https://onslowsites.com)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:36:"Reply-To: support@redhammerworks.com";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'); 
INSERT INTO `wp_postmeta` VALUES ('10', '10', '_messages', 'a:8:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:22:"The field is required.";s:16:"invalid_too_long";s:22:"The field is too long.";s:17:"invalid_too_short";s:23:"The field is too short.";}'); 
INSERT INTO `wp_postmeta` VALUES ('11', '10', '_additional_settings', ''); 
INSERT INTO `wp_postmeta` VALUES ('12', '10', '_locale', 'en_US'); 
INSERT INTO `wp_postmeta` VALUES ('13', '11', '_email', 'support@redhammerworks.com'); 
INSERT INTO `wp_postmeta` VALUES ('14', '11', '_name', 'darwinhadley'); 
INSERT INTO `wp_postmeta` VALUES ('15', '11', '_props', 'a:2:{s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('16', '11', '_last_contacted', '2017-03-27 16:41:47'); 
INSERT INTO `wp_postmeta` VALUES ('17', '12', '_email', 'maddy@heysaturday.com'); 
INSERT INTO `wp_postmeta` VALUES ('18', '12', '_name', 'maddyaman'); 
INSERT INTO `wp_postmeta` VALUES ('19', '12', '_props', 'a:2:{s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('20', '12', '_last_contacted', '2017-03-27 16:41:47'); 
INSERT INTO `wp_postmeta` VALUES ('21', '13', '_email', 'tpope@heysaturday.com'); 
INSERT INTO `wp_postmeta` VALUES ('22', '13', '_name', 'thecklapope'); 
INSERT INTO `wp_postmeta` VALUES ('23', '13', '_props', 'a:2:{s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('24', '13', '_last_contacted', '2017-03-27 16:41:47'); 
INSERT INTO `wp_postmeta` VALUES ('28', '15', '_name', 'saturdaydev'); 
INSERT INTO `wp_postmeta` VALUES ('29', '15', '_props', 'a:2:{s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('27', '15', '_email', 'nick@heysaturday.com'); 
INSERT INTO `wp_postmeta` VALUES ('30', '15', '_last_contacted', '2019-04-30 19:44:35'); 
INSERT INTO `wp_postmeta` VALUES ('31', '18', '_email', 'tom@bluegravity.com'); 
INSERT INTO `wp_postmeta` VALUES ('32', '18', '_name', 'bluegravity'); 
INSERT INTO `wp_postmeta` VALUES ('33', '18', '_props', 'a:2:{s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";}'); 
INSERT INTO `wp_postmeta` VALUES ('34', '18', '_last_contacted', '2019-12-16 20:53:34');
# --------------------------------------------------------

