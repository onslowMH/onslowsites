CREATE TABLE IF NOT EXISTS `wp_domain_mapping` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blog_id` bigint(20) NOT NULL,
  `domain` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` tinyint(4) DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `blog_id` (`blog_id`,`domain`,`active`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
TRUNCATE TABLE `wp_domain_mapping`;
 
INSERT INTO `wp_domain_mapping` VALUES ('1', '2', 'onslowradiationoncology.org', '1'); 
INSERT INTO `wp_domain_mapping` VALUES ('2', '2', 'onslowradiationoncology.com', '0'); 
INSERT INTO `wp_domain_mapping` VALUES ('3', '2', 'onslowradiation.org', '0'); 
INSERT INTO `wp_domain_mapping` VALUES ('4', '3', 'onslowurology.com', '0'); 
INSERT INTO `wp_domain_mapping` VALUES ('5', '3', 'onslowurology.org', '1'); 
INSERT INTO `wp_domain_mapping` VALUES ('6', '3', 'onslowurologyassociates.org', '0'); 
INSERT INTO `wp_domain_mapping` VALUES ('7', '3', 'onslowurologyassociates.com', '0'); 
INSERT INTO `wp_domain_mapping` VALUES ('8', '4', 'onslowpulmonology.org', '1'); 
INSERT INTO `wp_domain_mapping` VALUES ('9', '4', 'onslowpulmonology.com', '0'); 
INSERT INTO `wp_domain_mapping` VALUES ('10', '4', 'onslowpulmonologyassociates.org', '0'); 
INSERT INTO `wp_domain_mapping` VALUES ('11', '4', 'onslowpulmonologyassociates.com', '0'); 
INSERT INTO `wp_domain_mapping` VALUES ('12', '5', 'onslowsurgical.com', '0'); 
INSERT INTO `wp_domain_mapping` VALUES ('13', '5', 'onslowsurgical.org', '1'); 
INSERT INTO `wp_domain_mapping` VALUES ('14', '5', 'onslowsurgicalclinic.com', '0'); 
INSERT INTO `wp_domain_mapping` VALUES ('15', '5', 'onslowsurgicalclinic.net', '0'); 
INSERT INTO `wp_domain_mapping` VALUES ('16', '5', 'onslowsurgicalclinic.org', '0'); 
INSERT INTO `wp_domain_mapping` VALUES ('17', '5', 'onslowsurgicalclinic.info', '0');
# --------------------------------------------------------

